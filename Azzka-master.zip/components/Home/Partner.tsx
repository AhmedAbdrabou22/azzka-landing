"use client";
import { FaHandshake } from "react-icons/fa";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";

import "swiper/css";
import "swiper/css/pagination";

const partners = [
    { name: "مصر للطيران", logo: "https://seeklogo.com/images/E/egyptair-logo-CE8E40F5E7-seeklogo.com.png" },
    { name: "الخطوط السعودية", logo: "https://vectorlogo.zone/logos/saudia/saudia-ar.svg" },
    { name: "طيران الإمارات", logo: "https://1000logos.net/wp-content/uploads/2020/05/Emirates-Logo.png" },
    { name: "Booking.com", logo: "https://seeklogo.com/images/B/booking-com-logo-9F9E94F2B6-seeklogo.com.png" },
    { name: "Expedia", logo: "https://seeklogo.com/images/E/expedia-logo-33C6AB21E5-seeklogo.com.png" },
    { name: "Visa", logo: "https://seeklogo.com/images/V/visa-logo-B4E8E0B2B3-seeklogo.com.png" },
    { name: "Mastercard", logo: "https://seeklogo.com/images/M/mastercard-logo-67A9876D10-seeklogo.com.png" },
    { name: "Fawry", logo: "https://seeklogo.com/images/F/fawry-logo-9A5826F4C7-seeklogo.com.png" },
    { name: "PayPal", logo: "https://seeklogo.com/images/P/paypal-logo-8BB0D6520B-seeklogo.com.png" },
    { name: "Vodafone", logo: "https://seeklogo.com/images/V/vodafone-logo-688A03FE69-seeklogo.com.png" },
    { name: "Orange", logo: "https://seeklogo.com/images/O/orange-logo-8FBC1A2F5A-seeklogo.com.png" },
    { name: "AWS", logo: "https://seeklogo.com/images/A/aws-logo-D237CE6E0A-seeklogo.com.png" },
    { name: "Microsoft Azure", logo: "https://seeklogo.com/images/M/microsoft-azure-logo-761C6D27F4-seeklogo.com.png" },
    { name: "QuickBooks", logo: "https://seeklogo.com/images/Q/quickbooks-logo-05D61D2B03-seeklogo.com.png" },
    { name: "SAP", logo: "https://seeklogo.com/images/S/sap-logo-723A1A84C6-seeklogo.com.png" },
    { name: "Odoo", logo: "https://seeklogo.com/images/O/odoo-logo-A59F46670C-seeklogo.com.png" },
];

export default function PartnersSection() {
    return (
        <section className="py-20 bg-white relative overflow-hidden" dir="rtl">
            <div className="max-w-7xl mx-auto px-5 relative">
                {/* Header */}
                <div className="text-center mb-16 space-y-4">
                    <div className="inline-flex items-center gap-2 bg-[#fe6813]/10 px-5 py-2 rounded-full">
                        <FaHandshake className="text-[#fe6813]" />
                        <span className="text-[#fe6813] font-bold">شركاؤنا</span>
                    </div>

                    <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                        يثقون بنا
                        <span className="text-[#fe6813]"> أكثر من 500 شركة</span>
                    </h2>

                    <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                        نفتخر بشراكتنا مع أكبر الشركات والمؤسسات في مجال السياحة والخدمات
                    </p>
                </div>

                {/* Swiper Slider */}
                <Swiper
                    modules={[Autoplay, Pagination]}
                    autoplay={{ delay: 1500, disableOnInteraction: false }}
                    loop
                    // pagination={{ clickable: true }}
                    dir="rtl"
                    spaceBetween={20}
                    breakpoints={{
                        320: { slidesPerView: 2 },
                        640: { slidesPerView: 3 },
                        768: { slidesPerView: 4 },
                        1024: { slidesPerView: 5 },
                        1280: { slidesPerView: 6 },
                    }}
                    className="pb-10"
                >
                    {partners.map((partner, i) => (
                        <SwiperSlide key={i}>
                            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 hover:border-[#fe6813]/40 transition-all duration-300 hover:scale-105 flex flex-col items-center justify-center gap-3 w-full h-32">
                                <img src={partner.logo} alt={partner.name} className="w-20 h-20 object-contain" />
                                <div className="text-gray-900 font-bold text-center text-sm">{partner.name}</div>
                            </div>
                        </SwiperSlide>
                    ))}
                </Swiper>
            </div>
        </section>
    );
}
