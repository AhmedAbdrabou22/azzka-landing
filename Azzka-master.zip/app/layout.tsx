import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import NavBar from "../components/Shared/NavBar";
import { Cairo } from "next/font/google";
import Footer from "../components/Shared/Footer";
const cairo = Cairo({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700"], // اختياري: حسب الحاجة
  variable: "--font-cairo",
});

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Azzka-اذكي   الشركات السياحية",
  description : "اذكي هو نظام احترافي متكامل لإدارة شركات السياحة، مصمم لتوفير تجربة سلسة وفعالة في تنظيم جميع العمليات التشغيلية. يشمل النظام وحدات الحسابات، الموارد البشرية، العمليات السياحية، إدارة العملاء، الأرشيف الإلكتروني، والمخازن، ليمنحك السيطرة الكاملة على أعمالك وتسهيل كل العمليات اليومية.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${cairo.className} antialiased`}>
        <NavBar/>

        {/* 🔹 هنا محتوى الصفحة */}
        <main className="">
          {children}
        </main>
        <Footer/>
      </body>
    </html>
  );
}
